### R code from vignette source 'c15-knitr-springer.rnw'


###################################################
### code chunk number 2: c15-s2-1
###################################################
R0 = 0.5
x = 1:50
i0 = 5
plot(i0 * x^(x - i0 - 1) * R0^(x - i0) * 
     exp(-x * R0)/factorial(x - i0), xlab="Outbreak size", 
     ylab="Probability", type="p")
R0 = 0.7
points(i0 * x^(x - i0 - 1) * R0^(x - i0) * 
     exp(-x * R0)/factorial(x - i0), pch = 2)
R0 = 0.9
points(i0 * x^(x - i0 - 1) * R0^(x - i0) * 
     exp(-x * R0)/factorial(x-i0), pch=3)
legend("topright", c("0.5", "0.7", "0.9"), pch = 1:3)


###################################################
### code chunk number 3: c15-s2-2
###################################################
#Iterated exponential
Ek=function(k, x){
out=rep(NA, k+1)
out[1]=1
for(i in 2:(k+1)){
out[i]=x^(out[i-1])
}
return(out)
}

#cumulative from single introduction
R0=0.9
fk=exp(-R0)*(Ek(20, exp(R0*exp(-R0)))[-1])
i0=1
#uncumulate
g=c(fk[1]^i0,diff(fk^i0))
plot(g, ylab="Probability", xlab="Length", log="y", pch=16)
#loop from 1 to 10 introductions
for(i0 in 1:10){
g=c(fk[1]^i0,diff(fk^i0))
lines(g)
}
points(g, pch=17)
legend("topright", c("1", "10"), pch=16:17)


###################################################
### code chunk number 4: c15-s3-1
###################################################
require(rworldmap)
#Day to 20 deaths
inv=apply(pdv$ts[,-1]<20, 2, sum)
newmap = getMap(resolution = "low")
plot(newmap, xlim = c(-7, 16), ylim = c(50, 61), asp = 1.5)
#Big circles are early invasion.
#The ^1.5 is to increase contrast of early vs late invasion 
invsymsize=(-(inv-275)/275)^1.5
symbols(pdv$coord$lon, pdv$coord$lat, circles=invsymsize, bg=gray(inv/275), inches=.15, add=TRUE)


###################################################
### code chunk number 5: c15-s3-2
###################################################
require(raster)
require(gdistance)
require(maptools)
require(rgdal)
require(maps)
# the wrld_simpl data set is from maptools package
data(wrld_simpl)
# make a default world projection
world_crs = crs(wrld_simpl)
world = wrld_simpl
worldshp = spTransform(world, world_crs)

# rasterize will set ocean to NA 
ras = raster(nrow=1000, ncol=1000)
worldmask = rasterize(worldshp, ras)
worldras = is.na(worldmask)

# set land to very high friction
worldras[worldras==0] <- 99
# create a friction object from the raster
tr = transition(worldras, function(x) 1/mean(x), 16)
tr = geoCorrection(tr, scl=FALSE)


###################################################
### code chunk number 6: c15-knitr-springer.rnw:168-169
###################################################
load("worldmap.rda")


###################################################
### code chunk number 7: c15-s3-3
###################################################
dmat99sc = matrix(NA, ncol = 25, nrow = 25)
par(mfrow = c(1, 2))
plot(A, xlim = c(-10, 20), ylim = c(45, 65))
for(i in 1:25){
   # function accCost uses the transition object 
   # and point of origin
   port_origin = structure(as.numeric(pdv$coord[i,3:2]), 
      .Dim=1:2)
   port_origin = project(port_origin, 
      crs(world_crs, asText = TRUE))
   A = accCost(tr, port_origin)
   for(k in i:25){
      port_destination= structure(as.numeric(pdv$coord[k,
         3:2]), .Dim=1:2)
      port_destination = project(port_destination, 
         crs(world_crs, asText = TRUE))
      path = shortestPath(tr, port_origin, port_destination, 
         output = "SpatialLines")
      t_path = shortestPath(tr, port_origin, port_destination)
      distance = costDistance(tr, port_origin, port_destination)
      lines(path, col = grey((i + 26)/56))
      dmat99sc[i, k] = dmat99sc[k, i] = distance[1, 1]
   }
}
plot(pdv$fs[1, ]/1000,as.vector(inv), 
   xlab="Friction distance", ylab = "Day")


###################################################
### code chunk number 9: c15-s4-1
###################################################
data(waller)
head(waller)


###################################################
### code chunk number 10: c15-s4-2
###################################################
require(scatterplot3d)
s3d = scatterplot3d(waller$x, waller$y, waller$month, 
     scale.y = 0.7, pch = 16, lwd = 2, 
     color = gray(waller$month/max(waller$month)), type = "h", 
     box = FALSE, xlab = "Easting", ylab = "Northing",
     zlab = "Month", angle = 120)
plane = lm(month ~ x + y, data = waller)
s3d$plane3d(plane)


###################################################
### code chunk number 11: c15-s4-4
###################################################
#speed
1/sqrt(plane$coef[2]^2+ plane$coef[3]^2)
#direction
360*atan2(plane$coef[3], plane$coef[2])/(2*pi)


###################################################
### code chunk number 12: c15-s5-1
###################################################
ip=tp=rep(NA,201)
R0=seq(1.2, 2.5, length=201)
for(i in 1:201){
times  = seq(0, 365, by=0.01)
paras  = c(mu = 0, N = 1, R0=R0[i], gamma = 1/7)
paras["beta"]=paras["R0"]*(paras["gamma"]+paras["mu"])
start = c(S=0.99999, I=0.00001, R = 0)*paras["N"]
out = ode(y = start, times = times, func = sirmod, parms = paras)
out=as.data.frame(out)
ip[i]=with(as.list(paras), 1-(1+log(R0))/R0)
tp[i]=out$time[which.min(abs(out$I-ip[i]))]
}
par(mfrow=c(1,2))
plot(R0, ip, type="l", xlab="Reproduction number", ylab="Peak prevalence")
plot(R0, tp, type="l", xlab="Reproduction number", ylab="Peak day")


###################################################
### code chunk number 14: c15-s6-1
###################################################
require(ncf)
data(m4494)
pre=m4494$year>=50 & m4494$year<60
post=m4494$year>=80 & m4494$year<90
late=m4494$year>90
s5059=Sncf(x=m4494$longlat[,1],y=m4494$longlat[,2],z=m4494$measles[,pre], latlon=TRUE)
s8089=Sncf(x=m4494$longlat[,1],y=m4494$longlat[,2],z=m4494$measles[,post], latlon=TRUE)
s90=Sncf(x=m4494$longlat[,1],y=m4494$longlat[,2],z=m4494$measles[,late], latlon=TRUE)
plot(s5059, ylim=c(-0.1,.6))
plot(s8089, add=TRUE)
plot(s90, add=TRUE)
legend("topright", c("50-59", "80-89", "90+"), lty=1, lwd=3, col=c(gray(0.6), gray(0.8), gray(0.8)))


###################################################
### code chunk number 15: c15-s7-1
###################################################
#TSIR transmission coefficients
btny=c(32.552, 36.048, 43.163, 36.072, 37.459, 36.692, 32.089, 35.116, 37.03, 29.915, 28.114, 20.413, 18.03, 17.027, 15.855, 15.85, 18.87, 21.152, 26.08, 35.359, 35.859, 34.128, 37.66, 34.19, 27.827, 38.87)


###################################################
### code chunk number 16: c15-s7-2
###################################################
tsirSpat = function(beta, alpha, B, N, p, c, inits, type = "det"){
   type = charmatch(type, c("det", "stoc"), nomatch = NA)
   if(is.na(type))
      stop("method should be \"det\", \"stoc\"")
   IT = dim(B)[1]
   s = length(beta)
   lambda = matrix(NA, nrow = IT, ncol = p)  
   I = matrix(NA, nrow = IT, ncol = p)
   S = matrix(NA, nrow = IT, ncol = p)
    
   I[1, ] = inits[[1]]
   lambda[1, ] = inits[[2]]
   S[1,] = inits$Snull
   cmat = matrix(c, ncol = p, nrow = p)
   diag(cmat) = 1 - c * p 
   for(i in 2:IT) {
      lambda = beta[((i - 2) %% s) + 1]*cmat %*% (I[i - 
         1,]^alpha)*S[i - 1,]/N 
      if(type == 2) {
                I[i,] = rpois(p, lambda)
            }
      if(type == 1) {
            I[i, ] = lambda
        }
        S[i, ] = S[i - 1, ] + B[i, ] - I[i, ]
    }
    return(list(I = I, S = S))
}


###################################################
### code chunk number 17: c15-knitr-springer.rnw:393-408
###################################################
NY = na.omit(dalziel[dalziel$loc=="NEW YORK",])
NY = NY[NY$year %in% c(1920:1940),]
cum.reg = smooth.spline(cumsum(NY$rec), 
   cumsum(NY$cases), df = 5)
D = - resid(cum.reg) #The residuals
rr = predict(cum.reg, deriv = 1)$y
Ic = NY$cases/rr
Dc = D/rr 
#Align lagged variables
seas = rep(1:26, 21)[1:545]
lInew = log(Ic[2:546])
lIold = log(Ic[1:545])
Dold = Dc[1:545]
N = NY$pop
lSold = log(0.051 * N[1:545] + Dold)


###################################################
### code chunk number 18: c15-s7-3
###################################################
p = 5
pinits = list(Snull = sample(exp(lSold), size = p), 
    Inull = sample(Ic,size=p))
sim2 = tsirSpat(beta = btny, alpha = 0.98,
   B = matrix(median(NY$rec), ncol = p, nrow = 2600),
   N = median(N), p = p, c = 0, inits = pinits, type = "stoc")
mean(cor(sim2$I)[upper.tri(cor(sim2$I))])
matplot(sim2$I, type="l", log="y", xlim=c(0,400),
    col = 1, xlab = "biweek", ylab = "I")


###################################################
### code chunk number 19: c15-s7-4
###################################################
#coupling
coup = seq(0, 0.025, by = 0.0005)

sync = gext = lext = matrix(NA, ncol = length(coup), nrow = 100)
for(k in 1:length(coup)){
for(j in 1:100){
    sim2 = tsirSpat(beta = btny, alpha = 0.98,
        B = matrix(median(NY$rec), ncol = p, nrow = 2600), 
        N = median(N), p = p, c = coup[k], inits = list(Snull =
             sample(exp(lSold), size = p), 
        Inull = sample(Ic, size = p)), type = "stoc")
        #global extinction time   
        gext[j, k] = 2600 - sum(apply(sim2$I, 1, sum) == 0)
        #fraction of local absence before extinction
        lext[j, k] = sum(sim2$I[1:gext[j, 
             k], ] == 0) / (gext[j, k] * p)
        #synchrony
        sync[j, k] = mean(cor(sim2$I)[upper.tri(cor(sim2$I))])
    }
}

###################################################
### code chunk number 21: c15-s7-5
###################################################
boxplot(sync, outline=FALSE, xaxt="n", xlab="coupling", ylim=c(0,1))
boxplot(lext, col=0, outline=FALSE, , xaxt="n", add=TRUE)
legend("right", c("Synchrony", "Local \n extinction"),  pch=22, pt.cex=2, pt.bg=c("gray", 0), bty="n")
boxplot(gext/26,  xaxt="n", xlab="coupling")
legend("topright", c("Extinction\n time (yrs)"),  pch=22, pt.cex=2, pt.bg=c("gray"), bty="n")


###################################################
### code chunk number 22: c15-s8-1
###################################################
#Fig A
mbtny = mean(btny) #mean beta
p = 10 #number of patches
seasseq = seq(0, 0.3, by = 0.01) #seasonality
sync = gext = lext = matrix(NA, ncol = length(sdseq), nrow = 500)

for(k in 1:length(seasseq)) {#loop over seasonality
    for(j in 1:500) { #500 times
        bnty = exp(scale(log(btny)) * seasseq[k] + log(mbtny))
        sim2 = tsirSpat(beta = bnty, alpha = 0.98,
            B = matrix(median(NY$rec), ncol = p, nrow = 780), 
            N = median(N), p = p, c = 0.001, inits = 
            list(Snull = sample(exp(lSold), size = p), Inull = 
            sample(Ic, size = p)), type = "stoc")
        gext[j, k] = 780 - sum(apply(sim2$I, 1, sum) == 0)
        lext[j,k]=sum(sim2$I[1:gext[j, k], ] == 
            0) / (gext[j, k] * p)
        #synchrony during year 10-30
        sync[j, k] = mean(cor(sim2$I[261:780, ])[upper.tri(
            cor(sim2$I[261:780, ]))])
    }
}
boxplot(sync, outline = FALSE, xaxt = "n", xlab = "Seasonality", 
    ylab = "Synchrony")


###################################################
### code chunk number 23: 15-s8-2
###################################################
#Fig B
seasseq = seq(0, 0.3, by = 0.01) #seasonality 
plot(NA, ylim = c(10, 1E4), xlim = range(seasseq), 
    log="y", ylab="Infected",  xlab="Seasonality")
    for(k in 1:length(seasseq)) {
        bnty = exp(scale(log(btny)) * seasseq[k] + log(mbtny))
        sim2 = tsirSpat(beta = bnty, alpha = 0.98,
            B = matrix(median(NY$rec), ncol = p, 
            nrow = 52000 - 20), N = median(N), p = p, c=0.001,
            inits =  list(Snull = sample(exp(lSold), size = p), 
           Inull = sample(Ic, size = p)), type = "stoc")
        points(rep(seasseq[k], 2000 - 20), sim2$I[seq(from = 521, 
            to = 52000, by = 26)], pch = 20, cex = 0.3)
}


