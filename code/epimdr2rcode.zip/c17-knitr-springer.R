### R code from vignette source 'c17-knitr-springer.rnw'

###################################################
### code chunk number 2: c17-s2-1
###################################################
data(fiv)
Day31 = fiv[fiv$Day==31, ]
dimnames(Day31)[[1]] = Day31$Id
Day31 = na.omit(Day31[, -c(1, 14,15,16)])
Day59 = fiv[fiv$Day==59, ]
dimnames(Day59)[[1]] = Day59$Id
Day59 = na.omit(Day59[, -c(1, 14,15,16)])


###################################################
### code chunk number 3: c17-s2-2
###################################################
data(chabaudi)
chabaudirbc = chabaudi[, -c(1,3,4,7,8,10,11)]


###################################################
### code chunk number 4: c17-s2-3
###################################################
chabaudirbcw = reshape(chabaudirbc, idvar = "Ind2",
     direction = "wide", timevar = "Day")
chabaudirbcw = chabaudirbcw[, -seq(4, 50, by = 2)]
names(chabaudirbcw)[2] = "Treatment"


###################################################
### code chunk number 5: c17-s3-1
###################################################
require(ade4)
pca31 = dudi.pca(Day31[, 1:11], scannf = FALSE, nf = 5)
#select 5 axes
groups = Day31$Treatment
s.arrow(dfxy = pca31$co[, 1:2] * 8, ylim = c(-7, 9), 
    sub = "Day 31", possub = "topleft", csub = 2)
s.class(dfxy = pca31$li[, 1:2], fac = groups, cellipse = 2, 
    axesell = FALSE, cstar = 0 , col = c(2:5), add.plot = TRUE)
add.scatter.eig(pca31$eig, xax = 1, yax = 2, 
    posi = "bottomright")


###################################################
### code chunk number 6: c17-s3-2
###################################################
par(mfrow=c(1,2))
boxplot(fiv$viremia[fiv$Day==59]/1E4~fiv$Treatment[fiv$Day==59], ylab="Viral load", xlab="Treatment")
pca59 = dudi.pca(Day59[, 1:11], scannf = FALSE, nf = 5)
groups = Day59$Treatment
s.arrow(dfxy = pca59$co[, 1:2]*7, xlim=c(-9, 9), ylim = c(-1, 5), 
    sub = "Day 59",  possub = "topleft", csub = 2)
s.class(dfxy = pca59$li[,1:2], fac = groups, cellipse = 2, 
    axesell = FALSE, cstar = 0 , col = c(2:5), add.plot = TRUE)
add.scatter.eig(pca59$eig, xax = 1, yax = 2, 
    posi = "bottomleft")


###################################################
### code chunk number 7: c17-s4-1
###################################################
require(MASS)
Day31sc = Day31
Day31sc[, 1:11] = apply(Day31[, 1:11],2,scale)


###################################################
### code chunk number 8: c17-s4-2
###################################################
lda31 = lda(Treatment ~ CD4 + CD8B + CD25 + FAS + 
     IFNg + IL_10 + IL_12 + lymphocyte + neutrophils +
     TNF_a, data = Day31sc)
plot(lda31)


###################################################
### code chunk number 9: c17-s4-3
###################################################
pr = predict(lda31, method = "plug-in")$class
table(pr, Day31sc$Treatment)


###################################################
### code chunk number 10: c17-s4-4
###################################################
ld1 = as.matrix(Day31sc[,attr(lda31$terms,
     "term.labels")])%*%matrix(lda31$scaling[, 1], ncol = 1)
ld2 = as.matrix(Day31sc[,attr(lda31$terms,
     "term.labels")])%*%matrix(lda31$scaling[, 2], ncol = 1)
groups = Day31$Treatment

contribs = lda31$svd/sum(lda31$svd)
s.arrow(dfxy = lda31$scaling[,1:2], sub = "Day 31", 
      possub = "topleft", csub = 2)
s.class(dfxy = cbind(ld1, ld2) * 2.5, fac = groups, 
     cellipse = 2,  axesell = FALSE, cstar = 0, 
     col = c(2:5), add.plot = TRUE)
add.scatter.eig(contribs, xax = 1, yax = 2, 
     posi = "bottomright")


###################################################
### code chunk number 11: c17-s4-5
###################################################
Day59sc = Day59
Day59sc[, 1:11] = apply(Day59[, 1:11], 2, scale)
lda59  =  lda(Treatment ~ CD4 + CD8B + CD25 + FAS + 
     IFNg + IL_10 + IL_12 + lymphocyte + neutrophils + 
     TNF_a, data = Day59sc)
pr = predict(lda59, method = "plug-in")$class
table(pr, Day59sc$Treatment)

ld1 = as.matrix(Day59sc[,attr(lda59$terms,
     "term.labels" )])%*%matrix(lda59$scaling[, 1], ncol = 1)
ld2 = as.matrix(Day59sc[,attr(lda59$terms,
     "term.labels" )])%*%matrix(lda59$scaling[, 2], ncol = 1)
groups = Day59$Treatment

contribs  =  lda59$svd/sum(lda59$svd)
s.arrow(dfxy = lda59$scaling[,1:2], sub = "Day 59", 
     possub = "topleft", csub = 2)
s.class(dfxy = cbind(ld1, ld2), fac = groups, cellipse = 2, 
     axesell = FALSE, cstar = 0 , col = c(2:5), add.plot = TRUE)
add.scatter.eig(contribs, xax = 1, yax = 2, 
     posi = "bottomright")


###################################################
### code chunk number 12: c17-s5-1
###################################################
Y = cbind(Day59sc$CD4, Day59sc$CD8B, Day59sc$CD25, 
     Day59sc$FAS, Day59sc$IFNg, Day59sc$IL_10, 
     Day59sc$IL_12, Day59sc$lymphocyte, 
     Day59sc$neutrophils, Day59sc$TNF_a)
X = Day59$Treatment
mova59 = manova(Y ~ X)
summary(mova59, test = "Pillai")


###################################################
### code chunk number 13: c17-s6-1
###################################################
require(ade4)
dead = ifelse(chabaudirbcw[,27] == 0, "dead", "alive")
pcarbc = dudi.pca(chabaudirbcw[, 3:27], scale = FALSE, 
     scannf = FALSE, nf = 5)
s.arrow(dfxy = pcarbc$co[, 1:2] * 3, xlim = c(-10, 10), 
     ylim = c(-5, 5), sub = "RBC", possub = "topleft", csub = 2)
s.class(dfxy = pcarbc$li[, 1:2]*.3, fac = as.factor(dead), 
     cellipse = 2, axesell = FALSE, cstar = 0 , 
     col = c(2:7), add.plot = TRUE)
add.scatter.eig(pcarbc$eig, xax = 1, yax = 2, 
     posi = "bottomright")


###################################################
### code chunk number 14: c17-s6-2
###################################################
chabaudirbcw2 = chabaudirbcw[dead == "alive",]
groups = chabaudirbcw2$Treatment
pcarbc2 = dudi.pca(chabaudirbcw2[, 3:27], scale = FALSE, scannf  =  
     FALSE, nf  =  5)
s.arrow(dfxy = pcarbc2$co[, 1:2] * 3, xlim = c(-4,9), 
     ylim = c(-5,5), sub = "RBC", possub = "topleft", csub = 2)
s.class(dfxy = pcarbc2$li[,1:2] * 0.3, fac = groups, cellipse = 2, 
     axesell = FALSE, cstar = 0 , col = c(2:7), add.plot = TRUE)
add.scatter.eig(pcarbc2$eig, xax = 1, yax = 2, 
     posi = "bottomright")


###################################################
### code chunk number 15: c17-s7-1
###################################################
par(mfrow = c(1, 2))
#Gets the experimental days
day = unique(chabaudi$Day)
#Calculate the average time series
avg = apply(chabaudirbcw2[, 3:27], 2, mean)
plot(day, avg, type = "b", ylim = range(chabaudirbcw2[, 3:27]), 
   ylab  =  "RBC", xlab = "Day")
title("Mean +/- 1 SD eof 1")
lines(day, avg + 1 * pcarbc2$co[, 1], col = 2, 
   type = "b", pch = "+")
lines(day, avg - 1 * pcarbc2$co[, 1], col = 2, 
   type = "b", pch = "-")
plot(day, avg, type = "b", ylim = range(chabaudirbcw2[, 3:27]), 
     ylab  =  "RBC", xlab = "Day")
title("Mean +/- 1 SD eof 2")
lines(day, avg + 1 * pcarbc2$co[, 2], col = 2, 
   type = "b", pch = "+")
lines(day, avg - 1 * pcarbc2$co[, 2], col = 2, 
   type = "b", pch = "-")


###################################################
### code chunk number 16: c17-s7-2
###################################################
par(mfrow = c(1,2))
so = order(pcarbc2$li[,1])
plot(day, t(chabaudirbcw2[so[1],3:27]), type = "l", ylab = "RBC", 
   xlab = "Day")
for (i in 1:5) lines(day, t(chabaudirbcw2[so[i], 3:27]))
for (i in 36:41) lines(day, t(chabaudirbcw2[so[i], 3:27]), 
   col = 2, lty = 2)
so = order(pcarbc2$li[,2])
plot(day, t(chabaudirbcw2[so[1], 3:27]), type = "l", ylab = "RBC", 
   xlab = "Day")
for (i in 1:5) lines(day, t(chabaudirbcw2[so[i], 3:27]))
for (i in 36:41) lines(day, t(chabaudirbcw2[so[i], 3:27]), 
   col = 2, lty = 2)


