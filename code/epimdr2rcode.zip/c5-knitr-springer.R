### R code from vignette source 'c5-knitr-springer.rnw'

###################################################
### code chunk number 2: c5-s2-1 (eval = FALSE)
###################################################
## glm(cbind(inf, notinf) ~ offset(log(a)), 
##      family = binomial(link = "cloglog")) 


###################################################
### code chunk number 3: c5-s2-2
###################################################
data(black)
black


###################################################
### code chunk number 4: c5-s2-3
###################################################
b2 = black[-c(1, 8, 9), ]  #subsetting age brackets
#Estimate log-FoI
fit = glm(cbind(pos,neg) ~ offset(log(mid)), 
    family = binomial(link = "cloglog"), data = b2)
#Plot predicted and observed
phi = exp(coef(fit))
curve(1 - exp(-phi * x), from = 0, to = 60, 
     ylab = "Seroprevalence", xlab = "Age")
points(black$mid, black$f, pch = "*", col = "red")
points(x = b2$mid, y = b2$f, pch = 8)
phi
1/phi


###################################################
### code chunk number 5: c5-s3-1
###################################################
data(rabbit)
head(rabbit)


###################################################
### code chunk number 6: c5-s3-2
###################################################
rabbit$notinf = rabbit$n - rabbit$inf
#Binomial regression
fit = glm(cbind(inf, notinf) ~ offset(log(a)), 
    family = binomial(link = "cloglog"),
    data = rabbit, subset = a < 12)
#Plot data
symbols(rabbit$inf/rabbit$n ~ rabbit$a, circles = rabbit$n, 
     inches = 0.5, xlab = "Age", ylab = "Prevalence")
#Predicted curves for <1 yr and all rabbits
phi = exp(coef(fit))
curve(1 - exp(-phi * x), from = 0, to = 12, add = TRUE)
curve(1 - exp(-phi * x), from = 0, to = 30, add = TRUE, 
     lty = 2)
1/phi


###################################################
### code chunk number 7: c5-s3-3
###################################################
integrandpc = function(a, up, foi){
  #Find which interval a belongs to
  wh = findInterval(a, sort(c(0,up)))
  #Calculate duration of each interval
  dur = diff(sort(c(0,up)))
  #Evaluate integrand
  inte = ifelse(wh == 1, foi[1]*a, 
       sum(foi[1:(wh-1)]*dur[1:(wh-1)])+
          foi[wh]*(a-up[wh-1]))
  return(inte)
}


###################################################
### code chunk number 8: c5-s3-4
###################################################
llik.pc = function(par, age, num, denom, up) {
    ll = 0
    for (i in 1:length(age)) {
        p = 1 - exp(-integrandpc(a=age[i], up = up, 
            foi = exp(par)))
        ll = ll + dbinom(num[i], denom[i], p, log = TRUE)
    }
return(-ll)
}


###################################################
### code chunk number 9: c5-s3-5
###################################################
x=c(1,4,8,12,18,24,30)
para=rep(.1,length(x))


###################################################
### code chunk number 10: c5-s3-6
###################################################
est = optim(par = log(para), fn = llik.pc, age = rabbit$a, 
     num = rabbit$inf,  denom = rabbit$n, up = x, 
     method = "Nelder-Mead")

###################################################
### code chunk number 12: c5-s3-7
###################################################
round(exp(est$par), 4)


###################################################
### code chunk number 13: c5-s3-8
###################################################
#Make space for left and right axes
par(mar = c(5, 5, 2, 5))
#Add beginning and ends to x and y for step plot
xvals = c(0, x)
yvals = exp(c(est$par, est$par[7]))
plot(xvals, yvals, type = "s", xlab = "age", ylab = "FoI")

#Superimpose predicted curve
par(new = T)
p = rep(0, 28)
for (i in 1:28) {
     p[i] = 1 - exp(-integrandpc(a = i, up = x, 
          foi = exp(est$par)))
}
plot(p ~ c(1:28), ylim = c(0, 1), type = "l", col = "red", 
     axes = FALSE, xlab = NA, ylab = NA)

#Add right axis and legend
axis(side = 4)
mtext(side = 4, line = 4, "Prevalence")
legend("right", legend = c("FoI", "Prevalence"),
     lty = c(1, 1), col = c("black", "red"))


###################################################
### code chunk number 14: c5-s4-1
###################################################
require(splines)
#Degrees-of-freedom
df=7
#Construct dummy lm object
dl=lm(inf~bs(a,df), data=rabbit)


###################################################
### code chunk number 15: c5-s4-2
###################################################
tmpfn=function(x,dl){
x=predict(dl, newdata=data.frame(a=x))
exp(x)}


###################################################
### code chunk number 16: c5-s4-3
###################################################
tmpfn2 = function(par, data, df){
   #Dummy lm object
   dl = lm(inf ~ bs(a,df), data = data)
   #Overwrite spline coefficients with new values
   dl$coefficients = par
   #Calculate log-likelihood 
   ll = 0
   for(i in 1:length(data$a)){
     p = 1 - exp(-integrate(tmpfn, 0, i, dl = dl)$value)
     ll = ll + dbinom(data$inf[i], data$n[i], p ,log = T)
   }
 return(-ll)
 }


###################################################
### code chunk number 17: c5-s4-4
###################################################
 para = rep(-1, df + 1)
 dspline = optim(par = para, fn = tmpfn2, data = rabbit, 
      df = df, method = "Nelder-Mead", control =
      list(trace = 2, maxit = 2000))


###################################################
### code chunk number 18: c5-knitr-springer.rnw:238-240
###################################################
para=rep(-1, df+1)


###################################################
### code chunk number 19: c5-s4-5
###################################################
par(mar = c(5, 5, 2, 5)) #Room for two axes
#Overwrite dummy object coefficients with MLEs
dl$coefficients = dspline$par 
#Age-prevalence plot
plot(tmpfn(rabbit$a,dl) ~ rabbit$a, type = "l", ylab = "FoI", 
     xlab = "Age (mos)", las = 1)
#Overlay FoI
par(new = TRUE)
p = rep(0, 28)
for (i in 1:28) {
     p[i] = 1 - exp(-integrate(tmpfn, 0, i, 
          dl = dl)$value)
}
plot(p ~ c(1:28), ylim = c(0,1), type = "l", col = "red", 
     axes = FALSE, xlab = NA, ylab = NA)
axis(side = 4, las = 1)
mtext(side = 4, line = 4, "Prevalence")
legend("topright", legend = c("FoI", "Prevalence"),
     lty = c(1,1), col = c("black", "red"))


###################################################
### code chunk number 20: c5-s5-1
###################################################
data(peru)
head(peru)
#Calculate cumulative incidence
peru$cumulative=cumsum(peru$incidence)
#Define denominator
peru$n=sum(peru$incidence)
par(mar = c(5,5,2,5)) #Make room for two axes and plot
#Plot incidence with cumulative overlaid
plot(peru$incidence~peru$age, type="b", xlab="Age", 
    ylab="Incidence")
par(new=T)
plot(peru$cumulative~peru$age, type="l", col="red", 
    axes=FALSE, xlab=NA, ylab=NA)
axis(side = 4)
mtext(side = 4, line = 4, "Cumulative")
legend("right", legend=c("Incidence", "Cumulative"),
    lty=c(1,1), col=c("black", "red"))


###################################################
### code chunk number 21: c5-knitr-springer.rnw:308-312
###################################################
up=c(1:20,30, 40, 50, 60, 70,100)
x = c(0, up)
para=rep(.1,length(x))

###################################################
### code chunk number 22: c5-s5-2
###################################################
#Upper age cut-offs
up = c(1:20, 30, 40, 50, 60, 70, 80)
para = rep(0.1, length(up)) #Inital values
#Minimize log-likelihood
est2 = optim(par = log(para),fn = llik.pc, age = peru$age, 
    num = peru$cumulative, denom = peru$n, up = up, 
    method = "Nelder-Mead", control =
    list(trace = 2, maxit = 2000))
#Step plot
x = c(0, up)
y = exp(c(est2$par, est2$par[26]))
plot(x, y, ylab = "Relative FoI", xlab = "Age", type = "s", 
    ylim = c(0, 0.25), xlim = c(0, 80))


###################################################
### code chunk number 23: c5-s5-3
###################################################
data3=peru[peru$age<45,]
df=5
para=rep(.1, df+1)


###################################################
### code chunk number 24: c5-s5-4
###################################################
#Prediction function
tmpfn=function(x,dl){
    x=predict(dl, newdata=data.frame(age=x))
exp(x)}
#Dummy lm object
dl=lm(cumulative~bs(age,df), data=data3)
#Log-likelihood function
tmpfn2=function(par,data, df){
    dl=lm(cumulative~bs(age,df), data=data)
    dl$coefficients=par
    ll=0
    for(a in 1:length(data$age)){
      p=((1-exp(-integrate(tmpfn,0,data$age[a],
         dl=dl)$value)))
      ll=ll+dbinom(data$cumulative[a],data$n[a],p,log=T)
    }
 return(-ll)
 }


###################################################
### code chunk number 26: c5-s5-5
###################################################
#Fit model
dspline.a45.df5 = optim(par = log(para), fn = tmpfn2,
     data = data3, df = df, method = "Nelder-Mead", 
     control = list(trace = 4, maxit = 5000))
#Overwrite dummy object coefficients with MLEs
dl$coefficients = dspline.a45.df5$par
plot(exp(predict(dl)) ~ data3$age, xlab = "Age", 
     ylab = "Relative FoI", type = "l")


###################################################
### code chunk number 27: c5-s5-6
###################################################
(exp(-integrate(tmpfn,0,15,dl=dl)$value))*(1-
     exp(-integrate(tmpfn,15,40,dl=dl)$value))


###################################################
### code chunk number 28: c5-s5-7
###################################################
redn = 0.5
(exp(- redn * integrate(tmpfn, 0, 15,dl = dl)$value))*(1 - 
    exp(-redn*integrate(tmpfn, 15, 40, dl = dl)$value))


