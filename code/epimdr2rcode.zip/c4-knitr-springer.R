### R code from vignette source 'c4-knitr-springer.rnw'

###################################################
### code chunk number 2: c4-s3-1
###################################################
data(polymod)
head(polymod)
x=y=polymod$contactor[1:30]
z=matrix(polymod$contact.rate, ncol=30, nrow=30)
image(x=x, y=y, z=z, xlab="Contactor", 
     ylab="Contactee", col=gray((12:32)/32))
contour(x=x, y=y, z=z, add=TRUE)


###################################################
### code chunk number 3: c4-s3-2
###################################################
plot(apply(z,1,mean)~x, ylab="Total contact rate",
     xlab="Age")


###################################################
### code chunk number 4: c4-s4-1
###################################################
require(fields)
n = length(x)
#symmetrize
z2 = (z + t(z))/2
z3 = as.vector(z2)
xy = data.frame(x = rep(x[1:n], n), 
     y = rep(y[1:n], each = n))
#smooth
polysmooth = Tps(xy, z3, df = 100)
surface(polysmooth, xlab = "", ylab = "", 
     col=gray((12:32)/32))


###################################################
### code chunk number 5: c4-s4-2
###################################################
n=70
ra=rep(1, 70) #aging rates
x=cumsum(1/ra) #age brackets
#annualize & symmetrize
ps=predict(polysmooth, x=expand.grid(1:70, 1:70))
ps2=matrix(ps, ncol=70)
ps2=ps2+t(ps2)
#normalice
W = ps2/mean(ps2)


###################################################
### code chunk number 6: c4-s4-3
###################################################
sirAgemod = function(t, logx,  parameters) {
    n=length(parameters$r)
    xx = exp(logx)
    S = xx[1:n]
    I = xx[(n + 1):(2 * n)]
    R = xx[(2 * n + 1):(3 * n)]
    with(as.list(parameters), {
        phi = (beta * W %*% I)/N
        dS = c(mu, rep(0, n - 1)) * N - (phi + r) * S + 
            c(0,r[1:(n - 1)] * S[1:(n - 1)]) - mu * S - v * S
        dI = phi*S + c(0, r[1:(n - 1)] * I[1:(n - 1)]) - 
            (gamma + r) * I - mu * I
        dR =  v * S + c(0, r[1:(n - 1)] * R[1:(n - 1)]) + 
          gamma * I - r * R - mu * R
        res = c(dS/S, dI/I, dR/R)
        list((res))
    })
}


###################################################
### code chunk number 7: c4-s4-4
###################################################
v.pre = rep(0, n)
paras = list(N = 1, gamma = 365/14, 
    mu = 0.02, beta = 100, W = W, v = v.pre, r = ra)
ystart = log(c(S = rep(0.099/n, n), I = rep(0.001/n, n),
    R = rep(0.9/n, n)))


###################################################
### code chunk number 8: c4-s4-5
###################################################
require(deSolve)
times=seq(0, 500, by = 1/52)
#polymod mixing
out = as.data.frame(ode(ystart, times, 
    sirAgemod, paras))
par(mfrow = c(1, 2)) #Room for side-by-side plots
#Time series of infecteds
matplot(times/52, exp(out[ ,(n + 2):(2 * n + 1)]), 
   type = "l", xlab = "Year", ylab = "Prevalence")
#homogenous mixing:
paras$W = matrix(1, ncol = n, nrow = n)
out2 = as.data.frame(ode(ystart, times, 
   sirAgemod, paras))
#Final age-prevalence curve
plot(x, t(exp(out2[2608, (n + 2):(2 * n+1)]))/sum(exp(out2[2608, 
    (n + 2):(2 * n+1)])), ylab = "Prevalence", 
    xlab = "Age", col = 2, pch = "*")
points(x, t(exp(out[2608, (n + 2):(2 * n + 1)]))/sum(exp(out[2608, 
    (n + 2):(2 * n + 1)])))
legend("topright", c("polymod", "homogenous"), col = 1:2, 
    pch = c("o", "*"))


###################################################
### code chunk number 9: c4-s4-6
###################################################
#polymod matrix
paras$W=W 
#60\% vaccination of second age-class
paras$v=c(0, -log(1-0.6)*ra[2], rep(0, n-2))
out3=as.data.frame(ode(ystart, times, 
    sirAgemod, paras))
#Mid-point for each age-bracket
x2=x-(1/ra/2)
#Equilibrium age-prevalence and MAI
pv3=t(exp(out3[2608, (n+2):(2*n+1)]))
sum(x2*pv3)/sum(pv3)
#Prevaccination
pv=t(exp(out[2608, (n+2):(2*n+1)]))
sum(x2*pv)/sum(pv)


###################################################
### code chunk number 10: c4-s4-7
###################################################
paras$W = matrix(1, ncol = n, nrow = n)
out4=as.data.frame(ode(ystart, times, 
    sirAgemod, paras))
#Equilibrium MAI
pv4=t(exp(out4[2608, (n+2):(2*n+1)]))
sum(x2*pv4)/sum(pv4)
#Prevaccination
pv2=t(exp(out2[2608, (n+2):(2*n+1)]))
sum(x2*pv2)/sum(pv2)


###################################################
### code chunk number 11: c4-s5-1
###################################################
n = 70
a = rep(1, 70)
ystart2 = log(c(S = rep(0.9989/n, n), I = rep(0.001/n, n), 
    R = rep(0.0001/n,n)))
paras = list(N = 1, gamma = 365/14, mu = 0.02, beta = 100, W = W, 
    v = v.pre, r=ra)
out5 = as.data.frame(ode(ystart2, times, sirAgemod, paras))

#year 1 relative risk
y1 = apply(t(exp(out5[1:52, (n + 2):(2 * n + 1)])), 1, sum)
y1=y1/sum(y1)

#year 2 relative risk
y10 = apply(t(exp(out5[(1:52) + 10 * 52, (n + 2):(2 * n + 1)])), 
    1, sum)
y10 = y10/sum(y10)

#endemic relative risk
yT = apply(t(exp(out5[(1:52) + 499 * 52, (n + 2):(2 * n + 1)])), 
    1, sum)
yT = yT/sum(yT)

plot(x, y10, lty = 2, type = "l", ylab = "Relative risk", 
    xlab = "Age")
points(x, yT, type = "b", col = 2, pch = "*")
points(x, y1, type = "b", pch = 1)

legend("topright", c("Virgin", "10yr", "Endemic"), col = c(1,
    1, 2), pch = c("o", NA, "*"), lty = c(NA, 2, NA))


###################################################
### code chunk number 12: c4-s6-1
###################################################
-log(1-0.75)/2


###################################################
### code chunk number 13: c4-s6-2
###################################################
-log(1-0.85)/(0.69/0.3)


###################################################
### code chunk number 14: c4-c6-3
###################################################
#N1 cover with time before switch
p1 = seq(0, 0.85, by = 0.01)
T1 = -log(1 - p1)/(0.69/0.3)
plot(T1, p1, type = "l", xlim = c(0, 2), ylim = c(0, 1), 
    xlab = "year", ylab = "cover")
#After switch
T2 = seq(0, 2 - max(T1), length = 100)
p2 = 1 - exp(-0.69 * T2)
#N1 cover
lines(T2 + max(T1), p2 * 0.15 + 0.85)
#N2 cover
lines(T2 + max(T1), p2, col = 2)
#total cover
lines(c(T1, T2 + max(T1)), c(p1 * 0.3, (p2 * 0.15 + 0.85) * 0.3 + 
    p2 * 0.7), lty = 2)
abline(v = max(T1), lty = 3)
abline(h = 0.85, lty = 3)
legend("topleft", c("N1", "N2", "All"), lty = c(1, 1, 2),
    col = c(1, 2, 1))


###################################################
### code chunk number 15: c4-s7-1
###################################################
fa<-c(0, 0.5, 1.2)
sa<-c(0.8, 0.8, 0)
L<-matrix(0, nrow=3, ncol=3)
#inserting fa vector in first row
L[1,]<-fa
#inserting sa in the subdiagonal:
L[row(L)==col(L)+1] <-sa[1:2]


###################################################
### code chunk number 16: c4-s7-2
###################################################
Na=matrix(0, nrow=65, ncol=3)
Na[1,]=c(10, 0, 0)
for(i in 2:65){
Na[i, ]=L%*%Na[i-1, ]
}
scatterplot3d(Na[1:30,], type="b", xlab=expression(n[0]),
  ylab=expression(n[1]), zlab=expression(n[2]))


###################################################
### code chunk number 17: c4-s7-3
###################################################
Tot=apply(Na, 1, sum)
#growth during last years
tail(Tot[2:65]/Tot[1:64])
#First EV is dominant and real only
Re(eigen(L)$values[1])

#Simulated age-structure for year 65
Na[65,]/sum(Na[65,])
#Normalized dominant eigen vector
Re(eigen(L)$vector[,1])/sum(Re(eigen(L)$vector[,1]))


###################################################
### code chunk number 18: c4-s8-1
###################################################
Ex=eigen(L)
#The dominant eigenvalue 
lambda = Ex$values[1]
lambda
#The dominant (right) eigenvector is
w = Ex$vectors[, 1]
w


###################################################
### code chunk number 19: 4-s8-2
###################################################
v = eigen(t(L))$vectors[, 1]
v


###################################################
### code chunk number 20: c4-s8-3
###################################################
sens = Re((v %*% t(w))/sum(v*w))
sens


###################################################
### code chunk number 21: c4-s8-4
###################################################
leslie = function(L){
    Ex = eigen(L)    #Eigendecompostition of matrix
    w = Re(Ex$vectors[, 1]) #right eigenvector
    lambda = Re(Ex$values[1])  #dominant eigenvalue
    v = Re(eigen(t(L))$vectors[, 1])    #left eigenvector 
    sens = (v %*% t(w))/sum(v * w)   #sensitivities
   elast = L  * sens/lambda      #elasticities
    #list of results
    res = list(lambda = lambda, right.eigenvector = w,    
        left.eigenvector = v, elasticity = elast,                       
        sensitivity = sens)
   return(res)
}


###################################################
### code chunk number 22: c4-s8-5
###################################################
leslie(L)$lambda
leslie(L)$elasticity


###################################################
### code chunk number 23: c4-s8-6
###################################################
L2<-matrix(0, nrow=8, ncol=8)
L2[1,]<-us$fa[1:8]
L2[row(L2)==col(L2)+1] <-us$sa[1:7]
#Annualized growth rate
(leslie(L2)$lambda)^(1/5)
#Elasticities
round(leslie(L2)$elasticity,2)


