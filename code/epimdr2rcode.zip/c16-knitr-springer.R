### R code from vignette source 'c16-knitr-springer.rnw'


###################################################
### code chunk number 2: c16-s2-1
###################################################
data(burnett)
plot(burnett$Generation, 
    burnett$NumberofHostsParasitized, 
    type = "b", ylab = "Numbers", xlab = "Generation")
lines(burnett$Generation, 
    burnett$NumberofHostsUnparasitized, 
    type = "b", col = 2, pch = 2)
legend("topleft", legend = c("Parasitoid", "Host"), 
    lty = c(1, 1), pch = c(1, 2), col = c(1, 2))


###################################################
### code chunk number 3: c16-s2-2
###################################################
nbmod = function(R, a, T = 100, H0 = 10, P0 = 1){
    #T is length of simulation (number of time-steps)
    #H0 and P0 are initial numbers
    H = rep(NA, T) #Host series
    P = rep(NA, T) #Parasitoid series
    H[1] = H0 #Initiating the host series
    P[1] = P0 #Initiating the parasitoid series

    for(t in 2:T) {
        H[t] = R * H[t - 1] * exp(- a * P[t - 1])
        P[t] = R * H[t - 1] * (1 - exp(- a * P[t - 1]))
    } 

    res = list(H = H, P = P) 
    return(res)
} 


###################################################
### code chunk number 4: c16-s2-3
###################################################
sim = nbmod(R = 1.1, a = 0.1)
time = 1:100
par(mfrow = c(1, 2))
plot(time, sim$H, type =  "l", xlab  =  "Generations", 
    ylab  =  "Host abundance", ylim = c(0, 14))
points(time, sim$P, type = "l", col = "red")
plot(sim$H, sim$P, type = "l", xlab = "Host abundance", 
    ylab = "Parasitoid abundance")


###################################################
### code chunk number 5: c16-s2-4
###################################################
aVals = seq(0, 1, by = 0.01)
tte = rep(NA, length(aVals))
for (i in c(1:length(aVals))){
    sim =  nbmod(R = 1.1, a = aVals[i], T = 500)
    tte[i] = min(which(sim$P == 0))
    }
plot(aVals, tte, type = "b", ylab = "TTE", 
    xlab = "Search efficiency")


###################################################
### code chunk number 6: c16-s2-5
###################################################
ssfn = function(par){
  R = exp(par[1])
  a = exp(par[2])
  sim = nbmod(R,a, T = 22, H0 = 10.1, P0 = 11.9)
  ss = sum((burnett$NumberofHostsUnparasitized-sim$H)^2 +
      (burnett$NumberofHostsParasitized-sim$P)^2)
 return(ss)
 }
par = log(c(2, 0.05)) 
fit = optim(par, ssfn)
exp(fit$par)


###################################################
### code chunk number 7: c16-s2-6
###################################################
sim = nbmod(R = 2.16767, a = 0.06812, T = 22, H0 = 10.1, 
    P0 = 11.9)
plot(burnett$Generation, 
   burnett$NumberofHostsParasitized, type = "b", 
   ylab = "Numbers", xlab = "Generation")
lines(burnett$Generation, sim$P)
lines(burnett$Generation, 
   burnett$NumberofHostsUnparasitized, type = "b", 
   col = 2, pch = 2)
lines(burnett$Generation, sim$H, col = 2)
legend("topleft", legend = c("Parasitoid", "NB-P", 
   "Host", "NB-H"), lty = c(1, 1, 1, 1), pch=c(1, NA, 2, NA),
   col=c(1, 1, 2, 2))


###################################################
### code chunk number 8: c16-s3-1
###################################################
paras=c(R = 2.17, a = 0.068)
eq = with(as.list(paras), c(P = log(R)/a, H= log(R) /(a*(R-1))))
#states
states=c("H", "P")
#equations
elist = c(Heq = quote(R * H * exp(-a * P)),
   Peq = quote(R * H * (1-exp(-a * P))))
#matrices
JJ = jacobian(states = states, elist = elist, 
   parameters = paras, pts = eq)
eigen(JJ, only.values = TRUE)$values
max(abs(eigen(JJ)$values))


###################################################
### code chunk number 9: c16-s3-2
###################################################
2 * pi/atan2(Im(eigen(JJ)$values[1]), 
   Re(eigen(JJ)$values[1]))


###################################################
### code chunk number 10: c16-s3-3
###################################################
RVals = seq(1.1, 3, by = 0.1)
per = rep(NA, length(RVals))
for(i in 1:length(RVals)){
    paras = c(R = RVals[i], a = 0.068)
    eq = with(as.list(paras), c(P = log(R)/a, 
        H= log(R) /(a*(R-1))))
    JJ = jacobian(states = states, elist = elist, 
       parameters = paras, pts = eq)
    per[i] = 2 * pi/atan2(Im(eigen(JJ)$values[1]),
        Re(eigen(JJ)$values[1]))
}
plot(RVals, per, type = "b", xlab = "R", ylab = "Period")


###################################################
### code chunk number 11: c16-s6-1
###################################################
#Dh is proportion of hosts that disperses 
#Dp is proportion of parasitoids that disperses
Dh = 0.5
Dp = 0.7
#xlen is width of the lattice (E-W)
#ylen is height of the lattice (N-S)
xlen = 30
ylen = 30


###################################################
### code chunk number 12: c16-s6-2
###################################################
hp.dyn = function(h, p, R, a){ 
   #hnew is the post-interaction host density
   hnew = R * h * exp(- a * p)
   #pnew is the post-interaction parasitoid density
   pnew = R * h * (1 - exp(- a * p))
   #the two vectors of results are stored in a "list"
   res = list(h = hnew, p = pnew)
   return(res)
} 


###################################################
### code chunk number 13: c16-s6-3
###################################################
xy = expand.grid(1:xlen, 1:ylen)
dmat = as.matrix(dist(xy))


###################################################
### code chunk number 14: c14-s5-4
###################################################
kh = ifelse(dmat < 2, Dh/8, 0)
kp = ifelse(dmat < 2, Dp/8, 0)
diag(kh) = 1 - Dh
diag(kp) = 1 - Dp


###################################################
### code chunk number 15: c16-s6-5
###################################################
IT = 600
hmat = matrix(NA, nrow=xlen * ylen, ncol = IT)
pmat = matrix(NA, nrow=xlen * ylen, ncol = IT)
hmat[, 1] = 0
pmat[, 1] = 0
hmat[23, 1] = 4
pmat[23, 1] = 1


