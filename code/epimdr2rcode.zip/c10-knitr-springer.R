### R code from vignette source 'c10-knitr-springer.rnw'


###################################################
### code chunk number 2: c10-s1-1
###################################################
data(rabies)
matplot(rabies[, 2:7], ylab = "Cases", xlab = "Month")
legend("topright", c("CT", "DE", "MD", "MA", 
   "NJ", "NY"), pch = as.character(1:6), col = 1:6)


###################################################
### code chunk number 3: c10-s3-1
###################################################
parms  = c(mu = 1/(50 * 52), N = 1, beta =  2.5, 
      gamma = 1/2)
N = parms["N"]
gamma = parms["gamma"]
beta = parms["beta"]
mu = parms["mu"]
Istar = as.numeric(mu * (beta/(gamma + mu) - 1)/beta)
Sstar = as.numeric((gamma + mu)/beta)
Sstar
Istar


###################################################
### code chunk number 4: c10-s3-2
###################################################
require(nleqslv)
rootfn = function(x, params){
   r = with(as.list(params),
      c(mu * (N  - x[1])  - beta * x[1]* x[2] / N,
      beta * x[1] * x[2] / N - (mu + gamma) * x[2],
      gamma * x[2] - mu * x[3]))
   r
}
parms  = c(mu = 1/(50 * 52), N = 1, beta =  2.5, 
   gamma = 1/2)
ans = nleqslv(c(0.1, 0.5, 0.4), fn = rootfn, 
   params = parms)
ans$x


###################################################
### code chunk number 5: c10-s3-4
###################################################
ans = grid = expand.grid(seq(0, 1, by = 0.25), 
   seq(0, 1, by =  0.25), seq(0, 1, by = 0.25))
ans[ , ] = NA
for(i in 1:nrow(ans)){
ans[i, ] = nleqslv(as.numeric(grid[i, ]), fn = rootfn, 
    params = parms)$x
}
ans2 = round(ans, 4)
ans2[!duplicated(ans2), ]


###################################################
### code chunk number 6: c10-s3-5
###################################################
sirmod = function(t, y, parameters){
   S = y[1]
   I = y[2]
   R = y[3]
   with(as.list(parameters),{
   dS = mu * (N  - S)  - beta * S * I / N
   dI = beta * S * I / N - (mu + gamma) * I
   dR = gamma * I - mu * R
   res = c(dS, dI, dR)
   list(res)
 })
 }

paras  = c(mu = 1/(50 * 52), N = 1, 
   beta =  2.5, gamma = 1/2)
equil = ode(y = c(S = 1 - 1E-4, I = 1E-4, R = 0), 
   times = seq(0, 1E5, by = 1), func = sirmod,
   parms = paras)
round(tail(equil[, -1], 1), 5)


###################################################
### code chunk number 7: c10-s4-1
###################################################
states=c("S", "I")


###################################################
### code chunk number 8: c10-s4-2
###################################################
elist=c(dS = quote(mu * (N  - S)  - beta * S * I / N),
    dI = quote(beta * S * I / N - (mu + gamma) * I))


###################################################
### code chunk number 9: c10-s4-3
###################################################
parms  = c(mu = 1 / (50 * 52), N = 1, beta =  2, 
   gamma = 1 / 2)


###################################################
### code chunk number 10: c10-s4-5
###################################################
JJ = jacobian(states = states, elist = elist, 
   parameters = parms, pts = eeq)
#Eigen values are:
eigen(JJ)$value


###################################################
### code chunk number 11: c10-s4-6
###################################################
2 * pi / Im(eigen(JJ)$value[1])


###################################################
### code chunk number 12: c10-s4-7
###################################################
deq = list(S = 1, I = 0, R = 0)
JJ = jacobian(states = states, elist = elist, 
   parameters = parms, pts = deq)
#Eigen values are:
eigen(JJ)$values


###################################################
### code chunk number 13: c10-s4-8
###################################################
parms  = list(mu = 1/(50 * 52), N = 1, beta =  0.3, 
   gamma = 1/2, S = 1, I = 0)
JJ=jacobian(states = states, elist = elist, 
   parameters = parms, pts = deq)
#Eigen values are:
eigen(JJ)$values
#R0
with(parms, beta/(mu+gamma))


###################################################
### code chunk number 14: c10-s5-1
###################################################
N = 1
gamma = 7 / 3.8 
omega = 1 / (52 * 4)
mu = 1 / (52 * 70)
R0 = 2.9 


###################################################
### code chunk number 15: c10-s5-2
###################################################
#R0 = beta / (gamma + mu)
beta = R0 * (gamma + mu)
paras = c(beta = beta, gamma = gamma, 
   mu = mu, omega = omega)


###################################################
### code chunk number 16: c10-s5-3
###################################################
Sstar = 1 / R0
Istar = mu * (1 - 1 / R0)/(gamma + mu - 
   (omega * gamma)/(omega + mu))
Rstar = gamma * Istar/(omega + mu)
eq = list(S = Sstar, I = Istar, R = Rstar)
eq


###################################################
### code chunk number 17: c10-s5-4
###################################################
#states
states=c("S", "I", "R")

#equations
elist=c(
dS = quote(mu * (1-S)  - beta * S * I / N +
    omega * R),
dI = quote(beta * S * I / N - (mu + gamma) * I),
dR = expression(gamma * I - (mu +omega) * R))

JJ = jacobian(states = states, elist = elist, 
   parameters = paras, pts = eq)


###################################################
### code chunk number 18: c10-s5-5
###################################################
round(eigen(JJ)$values, 4)
2 * pi/Im(eigen(JJ)$values)[1]


###################################################
### code chunk number 19: c10-s5-6
###################################################
A = (omega + mu + gamma)/((omega + 
   mu) * (beta - gamma - mu))
GI = 1/(gamma + mu)
GR = 1/(omega + mu)
T = 4 * pi/sqrt(4 * (R0 - 1)/(GI * GR) - 
   ((1/GR) - (1/A))^2)
T


###################################################
### code chunk number 20: c10-s6-1
###################################################
coyne2 = function(t, logx, parms){
   x = exp(logx)
   S = x[1]
   E1 = x[2]
   E2 = x[3]
   I = x[4]
   R = x[5]
   N = sum(x)
   with(as.list(parms),{
     dS = a * (S + R) - beta * S * I - 
        (b + c + d * N) * S 
     dE1= lambda * beta * S * I  - (b + c + d * N) * E1  -
        sigma * E1
     dE2= (1-lambda) * beta * S * I - (b + c + d * N) * E2  -
        sigma * E2
     dI = sigma * E1  - (b + c + d * N) * I  -
        alpha * I
     dR = sigma * E2 - (b + d +c * N) * R
     res = c(dS/S, dE1/E1, dE2/E2, dI/I, dR/R)
     list(res)
   })
}


###################################################
### code chunk number 21: c10-s6-2
###################################################
times  = seq(0, 100, by = 1/520)
paras  = c(d = 0.0397, b = 0.836, a = 1.34, 
   sigma = 7.5, alpha = 66.36, beta = 33.25, 
   c = 0, lambda = 0.8)
start = log(c(S = 12.69/2, E1 = 0.1, E2 = 0.1, 
   I = 0.1, R = 0.1))
out = as.data.frame(ode(start, times, coyne2, paras))


###################################################
### code chunk number 22: c10-s6-3
###################################################
par(mfrow = c(1, 2))  
plot(times, exp(out$I), ylab = "Infected", xlab = "Time", 
     type = "l")
plot(exp(out$S), exp(out$I), ylab = "Infected", 
     xlab = "Susceptible", type = "l")


###################################################
### code chunk number 23: c10-s6-4
###################################################
#states
states=c("S", "E1", "E2", "I", "R")

#equations
elist = c(dS = quote(a * (S + R) - beta * S * I - 
     d * (S + E1 + E2 + I + R) * S  - (b + c) * S),
dE1= quote(lambda * beta * S * I  - 
     d * (S + E1 + E2 + I + R) * E1  - (b + sigma + c) * E1),
dE2 = quote((1-lambda) * beta * S * I  - 
     d * (S + E1 + E2 + I + R) * E2  - (b + sigma + c) * E2),
dI = quote(sigma * E1  - d * (S + E1 +
     E2 + I + R) * I  - (b + alpha + c) * I),
dR = quote(sigma * E2 - d * (S + E1 +
     E2 + I + R) * R  - (b + c) * R))


###################################################
### code chunk number 24: c10-s6-5
###################################################
equil=exp(tail(out[, -1], n=1))


###################################################
### code chunk number 25: c10-s6-6
###################################################
#Evaluate Jacobian elements
JJ = jacobian(states = states, elist = elist, 
   parameters = paras, pts = equil)
#Eigen decomposition
wh = which.max(Re(eigen(JJ, only.values = TRUE)$values))
round(eigen(JJ)$values, 4)


###################################################
### code chunk number 26: c10-s6-7
###################################################
2 * pi/Im(eigen(JJ)$values[wh])


###################################################
### code chunk number 27: c10-s6-8
###################################################
paras["lambda"] = 0.95
paras["d"] = 0.1
out = as.data.frame(ode(start, times, coyne2, paras))
equil = exp(tail(out[, -1], n = 1))
JJ = jacobian(states = states, elist = elist, 
   parameters = paras, pts = equil)
wh = which.max(Re(eigen(JJ, only.values = TRUE)$values))
2 * pi/Im(eigen(JJ)$values[wh])


###################################################
### code chunk number 28: c10-s7-1
###################################################
nextgenR0=function(Istates, Flist, Vlist, parameters, dfe){
paras = as.list(c(dfe, parameters)) 
k=0
vl=fl=list(NULL)
for(i in 1:length(Istates)){
assign(paste("f", i, sep = "."), lapply(lapply(Flist, deriv, Istates[i]), eval, paras))
assign(paste("v", i, sep = "."), lapply(lapply(Vlist, deriv, Istates[i]), eval, paras))
for(j in 1:length(Istates)){
k=k+1
fl[[k]]=attr(eval(as.name(paste("f", i, sep=".")))[[j]], "gradient")[1,]
vl[[k]]=attr(eval(as.name(paste("v", i, sep=".")))[[j]], "gradient")[1,]
}
}
f=matrix(as.numeric(as.matrix(fl)[,1]), ncol=length(Istates))
v=matrix(as.numeric(as.matrix(vl)[,1]), ncol=length(Istates))
R0=max(eigen(f%*%solve(v))$values)
return(R0)
}


###################################################
### code chunk number 29: c10-s7-2
###################################################
#STEP 1: Infected classes
istates = c("E1", "E2", "I")

#STEP 2: All new infections
flist=c(dE1=quote(lambda * beta * S * I), 
   dE2=quote((1-lambda) * beta * S * I), 
   dIdt=quote(0))

#STEP 3--5:
#Losses from E1, E2, I
Vm1 = quote(d * (S + E1 + E2 + I + R) * E1  + (b + sigma + c) * E1)
Vm2 = quote(d * (S + E1 + E2 + I + R) * E2  + 
   (b + sigma + c) * E2)
Vm3 = quote(d * (S + E1 + E2 + I + R) * I  + (b + alpha + c) * I)

#Gained transfers
Vp1 = 0
Vp2 = 0
Vp3 = quote(sigma * E1)

#To Make Vlist, subtract Vp from Vm
V1 = substitute(a - b, list(a = Vm1, b = Vp1))
V2 = substitute(a - b, list(a = Vm2, b = Vp2))
V3 = substitute(a - b, list(a = Vm3, b = Vp3))
vlist = c(V1, V2, V3)

#STEP 7: 
#Define parameters
paras = c(d = 0.0397, b = 0.836, a = 1.34, sigma = 7.5, 
   alpha = 66.36, beta = 33.25, c = 0, lambda = 0.8)
   
#Specify the disease free equilibrium
df = list(S = 12.69, E1 = 0, E2=0, I = 0, R = 0)

#STEP 6 and 8:
#Invoke R0 calculator
nextgenR0(Istates = istates, Flist = flist, Vlist = vlist, 
   parameters = paras, dfe = df)


###################################################
### code chunk number 30: c10-s7-3
###################################################
d=seq(0.02, 3, by = 0.01)
K=(paras["a"] - paras["b"])/d
R0=rep(NA, length(d))
for(i in 1:length(d)){
   paras["d"] = d[i]
   R0[i] = nextgenR0(Istates = istates, Flist = flist, 
   Vlist=vlist, parameters=paras, dfe=df)
}
plot(K, R0, type = "l", lwd = 2, ylab = expression(R[0]))
abline(h = 1)
K[which(R0<1)[1]]


###################################################
### code chunk number 31: c10-s8-1
###################################################
paras  = c(mu = 1/(50 * 52), N = 1, 
   beta =  2.5, gamma = 1/2)
eq = with(as.list(paras), c(S = (gamma + mu)/beta,
   I = mu * (beta/(gamma + mu) - 1)/beta))


###################################################
### code chunk number 32: c10-s8-2
###################################################
#states
states=c("S", "I")

#equations
elist = c(dS = quote(mu * (N  - S)  - beta * S * I / N),
   dI = quote(beta * S * I / N - (mu + gamma) * I))

JJ = jacobian(states = states, elist = elist, 
   parameters = paras, pts = eq)


###################################################
### code chunk number 33: c10-s8-3
###################################################
a1 = D(elist$dS, "beta")
a2 = D(elist$dI, "beta")
A = with(as.list(c(paras, eq)), 
   matrix(c(eval(a1), eval(a2)), ncol = 1))
Id = diag(2)


###################################################
### code chunk number 34: c10-s8-4
###################################################
wseq = seq(0, pi, length = 500)
Fr = vector("list", 500)  #set up empty list of matrices
#Loop to fill  matrices for each frequency
for(i in 1:500){ 
   #Solve gives matrix inverse
   Fr[[i]] = matrix(solve(Id * 1i * wseq[i]-JJ)%*%A, ncol=1) 
}


###################################################
### code chunk number 35: cc10-s8-5
###################################################
PS = matrix(NA, ncol = 2, nrow = 500, 
    dimnames = list(1:500, c("S","I"))) 
#Power spectra from real and imaginary 
# parts of the Fourier transform
for(i in 1:500){
    PS[i, ] = sqrt(Re(Fr[[i]])^2 + Im(Fr[[i]])^2)
}
plot(wseq, PS[,2], type = "l", log = "x", 
    xlab = "Frequency (in radians)", ylab = "Amplitude")
#The dominant period in weeks
2 * pi/wseq[which.max(PS[, 2])] 


###################################################
### code chunk number 36: c10-s8-6
###################################################
paras  = c(B = 800, beta =  5, alpha = 0.97, N = 1E6)
eq = with(as.list(paras), c(S = B^(1 - alpha) * N/beta,
   I = B))


###################################################
### code chunk number 37: c10-s8-9
###################################################
#states
states=c("S", "I")
#equations
elist = c(Seq = quote(S-beta * S * I^alpha/N+B),
   Ieq = quote(beta * S * I^alpha/N))
#matrices
JJ = jacobian(states = states, elist = elist, 
   parameters = paras, pts = eq)

a1 = D(elist$Seq, "beta")
a2 = D(elist$Ieq, "beta")
A = with(as.list(c(paras, eq)), 
   matrix(c(eval(a1), eval(a2)), ncol = 1))
Id = diag(2)


###################################################
### code chunk number 38: c10-s9-3
###################################################
evs = eigen(JJ)$values
2 * pi/atan2(Im(evs[1]), Re(evs[1]))


###################################################
### code chunk number 39: c10-s8-10
###################################################
wseq = seq(0, pi, length = 500)
Fr = vector("list", 500)  #Set up empty list of matrices

#Loop to fill those matrices with Fourier transforms
for(i in 1:500){ 
   #Solve gives matrix inverse
   Fr[[i]] = matrix(solve(Id-exp(1i * wseq[i]) * JJ)%*%
      A, ncol = 1)  
}
#Power spectrum
PS = matrix(NA,ncol = 2,nrow = 500, 
   dimnames = list(1:500,  c("S", "I"))) 
#Power spectra from real and imaginary parts
for(i in 1:500){
   PS[i,] = sqrt(Re(Fr[[i]])^2 + Im(Fr[[i]])^2)
}
#Peak in spectrum
2 * pi/wseq[which.max(PS[, 2])]


###################################################
### code chunk number 40: c10-knitr-springer.rnw:663-680
###################################################
tsirSim=function(alpha=0.97, B=2300, beta=25, sdbeta=0,
    S0 = 0.06, I0=180, IT=520, N=3.3E6){
    lambda = rep(NA, IT)
    I = rep(NA, IT)
    S = rep(NA, IT)
    I[1] = I0
    lambda[1] = I0
    S[1] = S0*N
    for(i in 2:IT) {
        lambda[i] = rnorm(1, mean=beta, sd=sdbeta) * I[i - 1]^alpha * S[i - 1] /N
        if(lambda[i]<0) {lambda[i]=0}
        I[i] = rpois(1, lambda[i])
        S[i] = S[i - 1] + B - I[i]
    }
    list(I = I, S = S)
}
load("tsirsim.rda")


###################################################
### code chunk number 41: c10-s9-5
###################################################
out = tsirSim(B = 800, beta = 5, sdbeta = 1, N = 1E6, 
     IT = 100*52, I0 = 10, S0 = 0.3)
plot(out$I[1:1040], xlab = "Biweek", ylab = "Incidence", 
     type = "l")


###################################################
### code chunk number 42: c10-s8-11
###################################################
sfit=spectrum(out$I[-c(1:104)])


###################################################
### code chunk number 43: c10-s8-12
###################################################
require(polspline)
sfit2 = lspec(out$I[-c(1:104)])
plot(wseq, PS[,2], type = "l", ylab = "Amplitude", 
     xlab = "Frequency (in radians)", xlim = c(0, 0.6))
lines(pi * sfit$freq/0.5, 
     5000 * sfit$spec/max(sfit$spec), col = 2)
par(new = TRUE)
plot(sfit2, col = 3, xlim = c(0, 0.6), axes = FALSE)
legend("topright", c("Transfer fn", "Periodogram", 
     "Log-spline"), lty = c(1, 1, 1), col = c(1, 2, 3))


###################################################
### code chunk number 44: c10-s10-1
###################################################
require(epimdr2)
runApp(seirs.app)
runApp(tsir.app)


